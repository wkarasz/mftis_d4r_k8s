package mftdocker;

import java.io.*;

public class ExecuteCMD {

	public String exec1(String[] args) {
		// This method return the status message
		try {
        	//Process p = Runtime.getRuntime().exec("cmd /C dir");
			String[] parts = args[0].split(" ");
        	Process p = Runtime.getRuntime().exec(parts);
        	BufferedReader in = new BufferedReader(
				new InputStreamReader(p.getInputStream()));
        	String line = null;
        	String message = "";
        	while ((line = in.readLine()) != null) {
        		System.out.println(line);
        		message += line + "\n"; 
        	}
        	p.waitFor();
            System.out.println(p.exitValue());
            //return;// p.exitValue();
            return message;
        } catch (Exception e) {
        	e.printStackTrace();
        }
		return "";
		
	}
	
	public int exec2(String[] args) {
		// This method return the status message
		try {
        	//Process p = Runtime.getRuntime().exec("cmd /C dir");
			String[] parts = args[0].split(" ");
        	Process p = Runtime.getRuntime().exec(parts);   	
			BufferedReader in = new BufferedReader(
				new InputStreamReader(p.getInputStream()));
        	String line = null;
        	while ((line = in.readLine()) != null) {
        		System.out.println(line); 
        	}
        	p.waitFor();
            System.out.println(p.exitValue());
            return p.exitValue();
        } catch (Exception e) {
        	e.printStackTrace();
        }
		return -1;
		
	}
	
	public static void main(String[] args) throws IOException {
	        
			
	        return; // -1;
	        //return "No result";
	    }
}
