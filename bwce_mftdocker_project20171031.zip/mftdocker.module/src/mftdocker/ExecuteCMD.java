package mftdocker;

import java.io.*;
import java.io.IOException;

public class ExecuteCMD {

	public static int main(String[] args) throws IOException {
	        try {
	        	//Process p = Runtime.getRuntime().exec("cmd /C dir");
	        	Process p = Runtime.getRuntime().exec(args[0].toString());
	        	BufferedReader in = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
	        	String line = null;
	        	while ((line = in.readLine()) != null) {
	        		System.out.println(line);
	        	}
	        	p.waitFor();
	            System.out.println(p.exitValue());
	            return p.exitValue();
	        } catch (Exception e) {
	        	e.printStackTrace();
	        }
			
	        return -1;
	    }

}
